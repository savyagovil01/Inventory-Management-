# ELC3143 Inventory Manager

## Overview
A local command-line prototype for tracking fictional department-store inventory. It supports item creation, listing, stock adjustments, and a low-stock report. Data is stored in SQLite in `inventory.db` in the current directory.

## Requirements and setup
- Python 3.10 or later
- No third-party runtime packages; the app uses Python's standard library.

From this directory, run `python app.py`. The database is created automatically. Choose menu options 1–4 to use the core workflows and 5 to exit.

## Tests
Run `python -m unittest -v`. Tests use a temporary database and do not alter the user's inventory database.

## Architecture
`app.py` contains an `Inventory` service that validates data and performs SQLite operations; `main()` provides the terminal menu. `test_app.py` tests the service using isolated temporary databases.

## Known limitations
Single-user, local-only prototype; no login, roles, audit history, item editing/deletion, barcode support, backup interface, or concurrent-user controls. It is not intended for real or confidential stock records.

## AI and third-party declaration
AI assistance (OpenAI Codex) was used to draft the prototype, tests, and report. The student must inspect, run, understand, and be able to explain all submitted work, and must follow the instructor's academic-integrity rules. No third-party libraries or external code templates are included.
