import tempfile
import unittest
from pathlib import Path
from app import Inventory


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.inv = Inventory(Path(self.tmp.name) / "test.db")

    def tearDown(self):
        self.tmp.cleanup()

    def test_add_and_list_item(self):
        self.inv.add_item("Resistor", 20, 5)
        self.assertEqual(self.inv.list_items()[0]["name"], "Resistor")

    def test_trim_name(self):
        self.inv.add_item("  Capacitor  ", 3)
        self.assertEqual(self.inv.list_items()[0]["name"], "Capacitor")

    def test_empty_name_rejected(self):
        with self.assertRaises(ValueError): self.inv.add_item(" ", 1)

    def test_negative_opening_quantity_rejected(self):
        with self.assertRaises(ValueError): self.inv.add_item("Wire", -1)

    def test_duplicate_case_insensitive_name_rejected(self):
        self.inv.add_item("LED", 1)
        with self.assertRaises(ValueError): self.inv.add_item("led", 2)

    def test_stock_increment(self):
        item = self.inv.add_item("Sensor", 4)
        self.assertEqual(self.inv.adjust_stock(item, 3), 7)

    def test_stock_decrement_to_zero(self):
        item = self.inv.add_item("Switch", 2)
        self.assertEqual(self.inv.adjust_stock(item, -2), 0)

    def test_stock_cannot_go_negative(self):
        item = self.inv.add_item("Fuse", 1)
        with self.assertRaises(ValueError): self.inv.adjust_stock(item, -2)

    def test_unknown_item(self):
        with self.assertRaises(LookupError): self.inv.adjust_stock(999, 1)

    def test_low_stock_threshold_is_inclusive(self):
        self.inv.add_item("Low", 2, 2)
        self.inv.add_item("Healthy", 3, 2)
        self.assertEqual([x["name"] for x in self.inv.low_stock()], ["Low"])

    def test_zero_reorder_level(self):
        self.inv.add_item("Out", 0, 0)
        self.assertEqual(len(self.inv.low_stock()), 1)


if __name__ == "__main__": unittest.main()
