"""Small, local inventory and stock management prototype for ELC3143."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path


class Inventory:
    def __init__(self, database: str | Path = "inventory.db"):
        self.database = str(database)
        with self._db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                quantity INTEGER NOT NULL CHECK(quantity >= 0),
                reorder_level INTEGER NOT NULL CHECK(reorder_level >= 0)
            )""")

    def _connect(self):
        db = sqlite3.connect(self.database)
        db.row_factory = sqlite3.Row
        return db

    @contextmanager
    def _db(self):
        db = self._connect()
        try:
            with db:
                yield db
        finally:
            db.close()

    def add_item(self, name: str, quantity: int, reorder_level: int = 0) -> int:
        name = name.strip()
        if not name:
            raise ValueError("Item name is required")
        if quantity < 0 or reorder_level < 0:
            raise ValueError("Quantity and reorder level must be non-negative")
        try:
            with self._db() as db:
                cur = db.execute("INSERT INTO items(name,quantity,reorder_level) VALUES(?,?,?)",
                                 (name, quantity, reorder_level))
                return int(cur.lastrowid)
        except sqlite3.IntegrityError as exc:
            raise ValueError("An item with that name already exists") from exc

    def list_items(self) -> list[dict]:
        with self._db() as db:
            return [dict(r) for r in db.execute("SELECT * FROM items ORDER BY name COLLATE NOCASE")]

    def adjust_stock(self, item_id: int, change: int) -> int:
        with self._db() as db:
            cur = db.execute("UPDATE items SET quantity=quantity+? WHERE id=? AND quantity+? >= 0",
                             (change, item_id, change))
            if cur.rowcount != 1:
                exists = db.execute("SELECT 1 FROM items WHERE id=?", (item_id,)).fetchone()
                if not exists:
                    raise LookupError("Item not found")
                raise ValueError("Stock cannot become negative")
            return int(db.execute("SELECT quantity FROM items WHERE id=?", (item_id,)).fetchone()[0])

    def low_stock(self) -> list[dict]:
        with self._db() as db:
            return [dict(r) for r in db.execute(
                "SELECT * FROM items WHERE quantity <= reorder_level ORDER BY name COLLATE NOCASE")]


def main():
    inventory = Inventory()
    print("ELC3143 Inventory Manager")
    while True:
        print("\n1 Add item  2 List items  3 Adjust stock  4 Low-stock report  5 Exit")
        choice = input("Choose: ").strip()
        try:
            if choice == "1":
                item_id = inventory.add_item(input("Name: "), int(input("Opening quantity: ")),
                                             int(input("Reorder level: ")))
                print(f"Added item #{item_id}")
            elif choice == "2":
                for item in inventory.list_items():
                    print(f"#{item['id']} {item['name']}: {item['quantity']} (reorder at {item['reorder_level']})")
            elif choice == "3":
                new_qty = inventory.adjust_stock(int(input("Item ID: ")), int(input("Change (+/-): ")))
                print(f"Updated quantity: {new_qty}")
            elif choice == "4":
                items = inventory.low_stock()
                print("Low stock:")
                for item in items:
                    print(f"#{item['id']} {item['name']}: {item['quantity']} <= {item['reorder_level']}")
                if not items:
                    print("No items at or below reorder level")
            elif choice == "5":
                break
            else:
                print("Choose a number from 1 to 5")
        except (ValueError, LookupError) as exc:
            print(f"Error: {exc}")
        except (EOFError, KeyboardInterrupt):
            print()
            break


if __name__ == "__main__":
    main()
